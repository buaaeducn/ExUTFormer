# projects/mmdet3d_plugin/hooks/geo_curriculum_hook.py
from mmcv.runner.hooks import HOOKS, Hook

@HOOKS.register_module()
class GeoCurriculumHook(Hook):
    """
    按 epoch 自动调度：
    - 开/关 extra 邻域分支（MSDeformableAttention3D.enable_extra）
    - 开/关 椭圆KNN（encoder.geo_knn_cfg.enable）
    - 調 K、sigma_deg（Σ_pix）
    - 开/关/渐变 外参噪声：prob / rot_std_deg / trans_std_m
    - 初始化/调整邻域权重 bias
    """

    def __init__(self,
                 total_epochs,
                 # 阶段占比（总和<=1.0；剩余给 Stage-2/3）
                 warmup_ratio=0.10,     # Stage-0
                 neigh_only_ratio=0.15, # Stage-1
                 final_ratio=0.15,      # Stage-3，末尾固定
                 # 阶段参数
                 k_stage1=8,
                 k_stage2=12,
                 k_stage3=12,
                 sigma_deg_stage1=1.0,
                 sigma_deg_stage2_end=1.0,
                 # 噪声从 Stage-2 开始线性升
                 noise_prob_range=(0.2, 0.6),
                 rot_deg_range=(0.3, 0.75),
                 trans_m_range=(0.01, 0.03),
                 # 邻域 bias（初始冷启动）
                 extra_bias_init=-1.0,
                 print_every_epoch=True):
        self.total_epochs = int(total_epochs)
        self.warmup_e = int(round(self.total_epochs * warmup_ratio))
        self.neigh_e  = int(round(self.total_epochs * neigh_only_ratio))
        self.final_e  = int(round(self.total_epochs * final_ratio))
        # 中间大段给 Stage-2
        self.stage2_start = self.warmup_e + self.neigh_e
        self.stage3_start = self.total_epochs - self.final_e

        self.k1, self.k2, self.k3 = k_stage1, k_stage2, k_stage3
        self.sigma1 = float(sigma_deg_stage1)
        self.sigma2_end = float(sigma_deg_stage2_end)

        self.p0, self.p1 = noise_prob_range
        self.r0, self.r1 = rot_deg_range
        self.t0, self.t1 = trans_m_range

        self.extra_bias_init = float(extra_bias_init)
        self.print_every_epoch = bool(print_every_epoch)

        # 标记：是否做过一次 bias 冷启动
        self._extra_bias_initialized = False

    # --------- 工具：找到 BEVFormer Encoder / MSDeformableAttention3D ----------
    def _find_modules(self, model):
        encoder = None
        extra_attn_list = []
        for m in model.modules():
            # 粗匹配：有 geo_knn_cfg / extrinsic_noise_cfg / point_sampling 的就是我们的 encoder
            if (hasattr(m, 'geo_knn_cfg') and hasattr(m, 'extrinsic_noise_cfg')
                    and hasattr(m, 'point_sampling')):
                encoder = m
            # 匹配注意力：类名判断，或带 extra_attention_weights 的
            if m.__class__.__name__ == 'MSDeformableAttention3D' and hasattr(m, 'extra_attention_weights'):
                extra_attn_list.append(m)
        return encoder, extra_attn_list

    def _set_extra_bias_once(self, extra_attn_list):
        if self._extra_bias_initialized:
            return
        for a in extra_attn_list:
            if a.extra_attention_weights is not None and hasattr(a.extra_attention_weights, 'bias'):
                try:
                    a.extra_attention_weights.bias.data.fill_(self.extra_bias_init)
                except Exception:
                    pass
        self._extra_bias_initialized = True

    # 线性插值
    def _lerp(self, a, b, t):
        return a + (b - a) * max(0.0, min(1.0, t))

    def before_train_epoch(self, runner):
        epoch = runner.epoch  # 从 0 开始
        model = runner.model
        # DDP unwrap
        if hasattr(model, 'module'):
            model = model.module

        encoder, extra_list = self._find_modules(model)
        if encoder is None:
            if self.print_every_epoch:
                runner.logger.warning('[GeoCurriculumHook] 未找到 BEV encoder，跳过。')
            return

        # 冷启动：给 extra 分支的 bias 置负
        self._set_extra_bias_once(extra_list)

        # 判阶段
        if epoch < self.warmup_e:
            # -------- Stage-0: 热身 --------
            # 关邻域、关噪声
            for a in extra_list:
                if hasattr(a, 'enable_extra'):
                    a.enable_extra = False
            encoder.geo_knn_cfg['enable'] = False

            encoder.extrinsic_noise_cfg['enable'] = False
            # log
            tag = f'Stage-0 | enable_extra=False, geo_knn=False, noise=False'

        elif epoch < (self.warmup_e + self.neigh_e):
            # -------- Stage-1: 仅邻域 --------
            for a in extra_list:
                if hasattr(a, 'enable_extra'):
                    a.enable_extra = True

            encoder.geo_knn_cfg['enable'] = True
            encoder.geo_knn_cfg['K'] = int(self.k1)
            encoder.geo_knn_cfg['sigma_deg'] = float(self.sigma1)
            encoder.geo_knn_cfg['use_sigma_points'] = True

            encoder.extrinsic_noise_cfg['enable'] = False
            tag = f'Stage-1 | enable_extra=True, geo_knn(K={self.k1}, σ={self.sigma1}°), noise=False'

        elif epoch < self.stage3_start:
            # -------- Stage-2: 邻域 + 逐步噪声 --------
            # 邻域开，K 调到中等
            for a in extra_list:
                if hasattr(a, 'enable_extra'):
                    a.enable_extra = True

            encoder.geo_knn_cfg['enable'] = True
            encoder.geo_knn_cfg['K'] = int(self.k2)
            # Σ_pix 的 σ 与旋转噪声同量级
            # t ∈ [0,1] 跨 Stage-2
            t = (epoch - self.stage2_start) / max(1, (self.stage3_start - self.stage2_start))
            encoder.geo_knn_cfg['sigma_deg'] = float(self._lerp(self.sigma1, self.sigma2_end, t))
            encoder.geo_knn_cfg['use_sigma_points'] = True

            # 外参噪声线性升
            encoder.extrinsic_noise_cfg['enable'] = True
            encoder.extrinsic_noise_cfg['prob'] = float(self._lerp(self.p0, self.p1, t))
            encoder.extrinsic_noise_cfg['rot_std_deg'] = float(self._lerp(self.r0, self.r1, t))
            encoder.extrinsic_noise_cfg['trans_std_m']  = float(self._lerp(self.t0, self.t1, t))
            # 训练时才加噪
            encoder.extrinsic_noise_cfg['apply_in'] = 'train'

            tag = (f'Stage-2 | extra=True, geo_knn(K={encoder.geo_knn_cfg["K"]}, σ={encoder.geo_knn_cfg["sigma_deg"]:.2f}°) | '
                   f'noise(prob={encoder.extrinsic_noise_cfg["prob"]:.2f}, '
                   f'rot={encoder.extrinsic_noise_cfg["rot_std_deg"]:.2f}°, '
                   f'trans={encoder.extrinsic_noise_cfg["trans_std_m"]:.3f}m)')

        else:
            # -------- Stage-3: 收尾稳态 --------
            for a in extra_list:
                if hasattr(a, 'enable_extra'):
                    a.enable_extra = True
            encoder.geo_knn_cfg['enable'] = True
            encoder.geo_knn_cfg['K'] = int(self.k3)
            encoder.geo_knn_cfg['use_sigma_points'] = True
            # 固定为 Stage-2 末值
            encoder.geo_knn_cfg['sigma_deg'] = float(self.sigma2_end)

            encoder.extrinsic_noise_cfg['enable'] = True
            encoder.extrinsic_noise_cfg['prob'] = float(self.p1)
            encoder.extrinsic_noise_cfg['rot_std_deg'] = float(self.r1)
            encoder.extrinsic_noise_cfg['trans_std_m']  = float(self.t1)
            encoder.extrinsic_noise_cfg['apply_in'] = 'train'

            tag = (f'Stage-3 | extra=True, geo_knn(K={encoder.geo_knn_cfg["K"]}, σ={encoder.geo_knn_cfg["sigma_deg"]:.2f}°) | '
                   f'noise(prob={encoder.extrinsic_noise_cfg["prob"]:.2f}, '
                   f'rot={encoder.extrinsic_noise_cfg["rot_std_deg"]:.2f}°, '
                   f'trans={encoder.extrinsic_noise_cfg["trans_std_m"]:.3f}m)')

        if self.print_every_epoch and hasattr(runner, 'logger'):
            runner.logger.info('[GeoCurriculumHook] epoch=%d %s' % (epoch, tag))


import numpy as np
import torch
import copy
import math
import warnings
from mmcv.cnn.bricks.registry import (ATTENTION,
                                      TRANSFORMER_LAYER,
                                      TRANSFORMER_LAYER_SEQUENCE)
from mmcv.cnn.bricks.transformer import TransformerLayerSequence
from mmcv.runner import force_fp32, auto_fp16
from mmcv.utils import TORCH_VERSION, digit_version
from mmcv.utils import ext_loader
from .custom_base_transformer_layer import MyCustomBaseTransformerLayer
ext_module = ext_loader.load_ext(
    '_ext', ['ms_deform_attn_backward', 'ms_deform_attn_forward'])


@TRANSFORMER_LAYER_SEQUENCE.register_module()
class BEVFormerEncoder(TransformerLayerSequence):

    """
    Attention with both self and cross
    Implements the decoder in DETR transformer.
    Args:
        return_intermediate (bool): Whether to return intermediate outputs.
        coder_norm_cfg (dict): Config of last normalization layer. Default：
            `LN`.
    """

    def __init__(self, *args, pc_range=None, num_points_in_pillar=4, return_intermediate=False, dataset_type='nuscenes',
                 knn_cfg = None, 
                 extrinsic_noise_cfg = None,
                 master_enable = True,
                 **kwargs):

        super(BEVFormerEncoder, self).__init__(*args, **kwargs)
        self.return_intermediate = return_intermediate

        self.num_points_in_pillar = num_points_in_pillar
        self.pc_range = pc_range
        self.fp16_enabled = False

        #-------------------KNN------------------#
        self.master_enable = bool(master_enable)
        default_knn = dict(enable = True, K = 4, radius = 2, include_center = True)
        self.knn_cfg = default_knn if knn_cfg is None else {**default_knn, **knn_cfg}
        #-------------------noise----------------#
        default_noise = dict(
            enable = True,
            prob = 0.01,  # 概率
            mode = 'gaussian', # 模型选择：gaussian/severity
            rot_std_deg = 0.75, # 度数旋转
            trans_std_m = 0.25,
            severity = None,
            apply_in = 'train'
        )
        print(default_noise['rot_std_deg'])
        print(default_noise['trans_std_m'])
        self.extrinsic_noise_cfg = default_noise if extrinsic_noise_cfg is None else {**default_noise, **extrinsic_noise_cfg}
        if not self.master_enable:
            self.knn_cfg['enable'] = False
            self.extrinsic_noise_cfg['enable'] = False
     # ===================== utils: SO(3) 指数映射 ===================== #
    @staticmethod
    def _skew(v):
        # v: (...,3)
        O = torch.zeros_like(v[..., :1])
        vx, vy, vz = v.unbind(-1)
        return torch.stack([
            torch.stack([ O[...,0], -vz,        vy], -1),
            torch.stack([ vz,       O[...,0],  -vx], -1),
            torch.stack([-vy,        vx,       O[...,0]], -1)
        ], -2)

    @classmethod
    # 根据得到的扰动omega，计算得到旋转矩阵
    def _so3_exp(cls, omega):
        # omega: (...,3) 轴角
        theta = torch.norm(omega, dim=-1, keepdim=True).clamp_min(1e-8)
        k = omega / theta
        K = cls._skew(k)
        I = torch.eye(3, device=omega.device, dtype=omega.dtype).expand(K.shape)
        s = torch.sin(theta)[..., None]
        c = torch.cos(theta)[..., None]
        R = I + s * K + (1.0 - c) * (K @ K)
        return R
    # ===================== utils: 噪声强度策略 ===================== #
    @staticmethod
    def _severity_to_std(sev):
        # 返回 (rot_std_rad, trans_std_m)
        sev = int(max(1, min(5, sev)))
        rot_deg = [0.05, 0.10, 0.15, 0.20, 0.30][sev - 1]
        trans_m = [0.01, 0.02, 0.03, 0.04, 0.05][sev - 1]
        return math.radians(rot_deg), trans_m

    def _resolve_noise_std(self, img_metas):
        """给出 (rot_std_rad, trans_std_m)"""
        cfg = self.extrinsic_noise_cfg
        mode = cfg.get('mode', 'gaussian')
        if mode == 'severity':
            sev = cfg.get('severity', 3) or 3
            return self._severity_to_std(sev)
        # gaussian 默认
        rot_std_deg = float(cfg.get('rot_std_deg', 0.15))
        trans_std_m = float(cfg.get('trans_std_m', 0.03))
        return math.radians(rot_std_deg), trans_std_m
    
    def _maybe_apply_extrinsic_noise(self, lidar2img, img_metas):
        """
        对 (B,N,4,4) 右乘 ΔT = [R_noise, t_noise]，仅训练 & 概率触发。
        """
        cfg = getattr(self, 'extrinsic_noise_cfg', None)
        if (cfg is None) or (not cfg.get('enable', False)):
            return lidar2img

        apply_in = cfg.get('apply_in', 'train')
        if apply_in == 'train' and (not self.training): # 仅仅在训练的时候加
            return lidar2img
        if apply_in == 'test' and self.training: # 仅仅在测试的时候加
            return lidar2img
    
        prob = float(cfg.get('prob', 0.0))
        if prob <= 0.0:
            return lidar2img
        if torch.rand(1, device=lidar2img.device) >= prob:
            return lidar2img

        B, N = lidar2img.shape[:2]
        rot_std_rad, trans_std_m = self._resolve_noise_std(img_metas)

        omega = torch.randn(B, N, 3, device=lidar2img.device, dtype=lidar2img.dtype) * rot_std_rad 
        # omega = 先生成标准正态分布，再乘以rot_std_rad，弧度
        t     = torch.randn(B, N, 3, device=lidar2img.device, dtype=lidar2img.dtype) * trans_std_m
        Rn = self._so3_exp(omega)  # [B,N,3,3]

        Delta = torch.eye(4, device=lidar2img.device, dtype=lidar2img.dtype).view(1,1,4,4).repeat(B,N,1,1)
        Delta[..., :3, :3] = Rn
        Delta[..., :3,  3] = t
        # 右乘：K[R|t] · ΔT
        print("run successfully add noise")
        return lidar2img @ Delta
            
    @staticmethod
    def _build_window_knn(reference_points_cam, bev_mask, img_metas, K=9, radius = 2, include_center = True):
        device = reference_points_cam.device
        dtype  = reference_points_cam.dtype
        H = img_metas[0]['img_shape'][0][0]
        W = img_metas[0]['img_shape'][0][1]

        uv = reference_points_cam  # [C,B,Q,D,2]，u=...,v=...
        u_px = uv[..., 0] * W
        v_px = uv[..., 1] * H

        # 以最近像素中心为基准（round 更贴近“像素中心”的 KNN）
        base_u = u_px.round()
        base_v = v_px.round()

                # 构造窗口内的整数偏移 (Δv, Δu)；注意 v 对应 H 轴，u 对应 W 轴
        d_range = torch.arange(-radius, radius + 1, device=device)
        dv, du = torch.meshgrid(d_range, d_range)
        dvdu    = torch.stack([dv, du], dim=-1).view(-1, 2)         # [M,2]
        if not include_center:
            keep = (dvdu.abs().sum(-1) != 0)
            dvdu = dvdu[keep]
        M = dvdu.size(0)

        # 候选像素坐标（像素域）
        cand_u = base_u.unsqueeze(-1) + dvdu[:, 1]  # [..., M]
        cand_v = base_v.unsqueeze(-1) + dvdu[:, 0]  # [..., M]

        # 与真实浮点落点的距离（像素）
        du2 = (cand_u - u_px.unsqueeze(-1)) ** 2
        dv2 = (cand_v - v_px.unsqueeze(-1)) ** 2
        dist2 = du2 + dv2  # [..., M]

        # Top-K 最近邻（K 不能超过 M）
        K_sel = min(K, M)
        topk_idx = dist2.topk(K_sel, dim=-1, largest=False).indices    # [..., K]
        cand_u = cand_u.gather(-1, topk_idx)                           # [..., K]
        cand_v = cand_v.gather(-1, topk_idx)                           # [..., K]

        # 归一化到 [0,1]
        neigh_u = cand_u / W
        neigh_v = cand_v / H
        ref_neighbors = torch.stack([neigh_u, neigh_v], dim=-1)        # [..., K, 2]

        # 越界 mask，并与 bev_mask 结合
        in_bound = (ref_neighbors[..., 0] > 0.0) & (ref_neighbors[..., 0] < 1.0) & \
                   (ref_neighbors[..., 1] > 0.0) & (ref_neighbors[..., 1] < 1.0)
        neighbor_mask = bev_mask.unsqueeze(-1) & in_bound              # [..., K]
        # print("KNN works")
        return ref_neighbors.to(dtype), neighbor_mask
    
    @staticmethod
    def get_reference_points(H, W, Z=8, num_points_in_pillar=4, dim='3d', bs=1, device='cuda', dtype=torch.float):
        """Get the reference points used in SCA and TSA.
        Args:
            H, W: spatial shape of bev.
            Z: hight of pillar.
            D: sample D points uniformly from each pillar.
            device (obj:`device`): The device where
                reference_points should be.
        Returns:
            Tensor: reference points used in decoder, has \
                shape (bs, num_keys, num_levels, 2).
        """

        # reference points in 3D space, used in spatial cross-attention (SCA)
        # 实际取的是体素的中心：0.5可以看到
        # zs:0.5-Z-0.5,取num_points_in_pillar个点 expand 扩展维度 /Z 归一化
        if dim == '3d':
            zs = torch.linspace(0.5, Z - 0.5, num_points_in_pillar, dtype=dtype,
                                device=device).view(-1, 1, 1).expand(num_points_in_pillar, H, W) / Z
            xs = torch.linspace(0.5, W - 0.5, W, dtype=dtype,
                                device=device).view(1, 1, W).expand(num_points_in_pillar, H, W) / W
            ys = torch.linspace(0.5, H - 0.5, H, dtype=dtype,
                                device=device).view(1, H, 1).expand(num_points_in_pillar, H, W) / H
            ref_3d = torch.stack((xs, ys, zs), -1)
            ref_3d = ref_3d.permute(0, 3, 1, 2).flatten(2).permute(0, 2, 1) # (num_points_in_pillar, H*W, 3)
            ref_3d = ref_3d[None].repeat(bs, 1, 1, 1) # (bs,num_points,H*W,3) 
            return ref_3d

        # reference points on 2D bev plane, used in temporal self-attention (TSA).
        elif dim == '2d':
            ref_y, ref_x = torch.meshgrid(
                torch.linspace(
                    0.5, H - 0.5, H, dtype=dtype, device=device),
                torch.linspace(
                    0.5, W - 0.5, W, dtype=dtype, device=device)
            )
            ref_y = ref_y.reshape(-1)[None] / H
            ref_x = ref_x.reshape(-1)[None] / W
            ref_2d = torch.stack((ref_x, ref_y), -1)
            ref_2d = ref_2d.repeat(bs, 1, 1).unsqueeze(2)
            return ref_2d

    # This function must use fp32!!!
    @force_fp32(apply_to=('reference_points', 'img_metas'))
    def point_sampling(self, reference_points, pc_range,  img_metas):
        # NOTE: close tf32 here.
        allow_tf32 = torch.backends.cuda.matmul.allow_tf32
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False

        lidar2img = []
        for img_meta in img_metas:
            lidar2img.append(img_meta['lidar2img'])
        lidar2img = np.asarray(lidar2img)
        lidar2img = reference_points.new_tensor(lidar2img)  # (B, N, 4, 4)
        #------------------------------------------
        lidar2img = self._maybe_apply_extrinsic_noise(lidar2img, img_metas)
        #------------------------------------------

        reference_points = reference_points.clone()
        # 将归一化后的坐标(x,y,z)(表示3D参考点)->映射回point_cloud_range
        reference_points[..., 0:1] = reference_points[..., 0:1] * \
            (pc_range[3] - pc_range[0]) + pc_range[0]
        reference_points[..., 1:2] = reference_points[..., 1:2] * \
            (pc_range[4] - pc_range[1]) + pc_range[1]
        reference_points[..., 2:3] = reference_points[..., 2:3] * \
            (pc_range[5] - pc_range[2]) + pc_range[2]
        # 多加一层维度，方便乘以外参(B, D, Q, 4)
        reference_points = torch.cat(
            (reference_points, torch.ones_like(reference_points[..., :1])), -1)

        reference_points = reference_points.permute(1, 0, 2, 3)
        D, B, num_query = reference_points.size()[:3]
        num_cam = lidar2img.size(1)
        # 将参考点复制到每一个相机：(D, B, N_cam, Q, 4, 1)
        reference_points = reference_points.view(
            D, B, 1, num_query, 4).repeat(1, 1, num_cam, 1, 1).unsqueeze(-1)

        lidar2img = lidar2img.view(
            1, B, num_cam, 1, 4, 4).repeat(D, 1, 1, num_query, 1, 1)

        reference_points_cam = torch.matmul(lidar2img.to(torch.float32),
                                            reference_points.to(torch.float32)).squeeze(-1) # (D, B, N_cam, Q, 4)
        eps = 1e-5

        bev_mask = (reference_points_cam[..., 2:3] > eps)
        reference_points_cam = reference_points_cam[..., 0:2] / torch.maximum(
            reference_points_cam[..., 2:3], torch.ones_like(reference_points_cam[..., 2:3]) * eps)

        reference_points_cam[..., 0] /= img_metas[0]['img_shape'][0][1]
        reference_points_cam[..., 1] /= img_metas[0]['img_shape'][0][0]

        bev_mask = (bev_mask & (reference_points_cam[..., 1:2] > 0.0)
                    & (reference_points_cam[..., 1:2] < 1.0)
                    & (reference_points_cam[..., 0:1] < 1.0)
                    & (reference_points_cam[..., 0:1] > 0.0))
        if digit_version(TORCH_VERSION) >= digit_version('1.8'):
            bev_mask = torch.nan_to_num(bev_mask)
        else:
            bev_mask = bev_mask.new_tensor(
                np.nan_to_num(bev_mask.cpu().numpy()))

        reference_points_cam = reference_points_cam.permute(2, 1, 3, 0, 4) # (N_cam, B, Q, D, 2)
        bev_mask = bev_mask.permute(2, 1, 3, 0, 4).squeeze(-1) # # (N_cam, B, Q, D)
        #---------------------------------------
        if self.knn_cfg.get('enable', False):
            ref_neighbors, neighbor_mask = self._build_window_knn(
                reference_points_cam, bev_mask, img_metas,
                K=self.knn_cfg['K'], radius=self.knn_cfg['radius'],
                include_center=self.knn_cfg['include_center']
            )
        else:
            ref_neighbors, neighbor_mask = None, None
        #----------------------------------------
        torch.backends.cuda.matmul.allow_tf32 = allow_tf32
        torch.backends.cudnn.allow_tf32 = allow_tf32

        return reference_points_cam, bev_mask, ref_neighbors, neighbor_mask