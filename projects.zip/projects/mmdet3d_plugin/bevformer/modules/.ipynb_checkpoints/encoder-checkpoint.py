import numpy as np
import torch
import copy
import warnings
from mmcv.cnn.bricks.registry import (ATTENTION,
                                      TRANSFORMER_LAYER,
                                      TRANSFORMER_LAYER_SEQUENCE)
from mmcv.cnn.bricks.transformer import TransformerLayerSequence
from mmcv.runner import force_fp32, auto_fp16
from mmcv.utils import TORCH_VERSION, digit_version
from mmcv.utils import ext_loader
from .custom_base_transformer_layer import MyCustomBaseTransformerLayer
ext_module = ext_loader.load_ext(
    '_ext', ['ms_deform_attn_backward', 'ms_deform_attn_forward'])
import math
# TODO the Z-depth=4 layers need to change
# TODO 而且没加上平移的误差
# TODO 为什么使用lidar2cam? 而不是lidar2img

@TRANSFORMER_LAYER_SEQUENCE.register_module()
class BEVFormerEncoder(TransformerLayerSequence):
    """
    BEVFormer Encoder with:
    - 总开关 master_enable
    - 外参噪声（左乘旋转 + 平移直加，或可选在相机系叠加）
    - 椭圆 KNN（雅可比→像素协方差 Σ_pix）+（向量化）Sigma-Points
    - 传统窗口KNN（备用）
    """

    def __init__(self, *args,
                 pc_range=None,
                 num_points_in_pillar=4,
                 return_intermediate=False,
                 dataset_type='nuscenes',
                 knn_cfg=None,                 # 传统窗口KNN（后备）
                 extrinsic_noise_cfg=None,     # 外参噪声
                 geo_knn_cfg=None,             # 椭圆KNN + Sigma-Points
                 master_enable=True,
                 **kwargs):
        super(BEVFormerEncoder, self).__init__(*args, **kwargs)
        self.return_intermediate = return_intermediate
        self.num_points_in_pillar = num_points_in_pillar
        self.pc_range = pc_range
        self.fp16_enabled = False

        # ================= 总开关 ================= #
        self.master_enable = bool(master_enable)

        # ================ 传统窗口KNN（后备） ================ #
        default_knn = dict(enable=False, K=12, radius=4, include_center=True)
        self.knn_cfg = default_knn if knn_cfg is None else {**default_knn, **knn_cfg}

        # ================ 外参噪声（左乘） ================ #
        default_noise = dict(
            enable=True,
            prob=0.5,
            mode='gaussian',
            rot_std_deg=0.75,     # σ_ω（度），建议 0.5~1.0；3°是上限
            trans_std_m=0.02,     # σ_t（米）
            trans_in_cam=False,   # True: t' = Rn@t + dt（相机系），False: t' = t + dt（你之前设定）
            severity=None,
            apply_in='train'
        )
        self.extrinsic_noise_cfg = default_noise if extrinsic_noise_cfg is None else {**default_noise, **extrinsic_noise_cfg}

        # ================ 椭圆KNN + Sigma-Points ================ #
        default_geo = dict(
            enable=True,
            K=12,
            sigma_deg=1.0,          # 旋转噪声 σ_ω（度），只用于 Σ_pix 的估计
            sigma_trans_m = 0.5,
            eps_pix2=1.0,           # Σ_pix 正则地板（像素^2）
            use_sigma_points=True,  # 使用 UT 7 个 sigma-points
            # UT 参数
            ut_alpha=1.0, ut_kappa=0.0, ut_beta=2.0,
        )
        self.geo_knn_cfg = default_geo if geo_knn_cfg is None else {**default_geo, **geo_knn_cfg}

        if not self.master_enable:
            self.knn_cfg['enable'] = False
            self.extrinsic_noise_cfg['enable'] = False
            self.geo_knn_cfg['enable'] = False

    # ===================== Math utils ===================== #
    @staticmethod
    #TODO 返回反对称矩阵
    def _skew(v):
        """ v: (...,3) → (...,3,3) """
        O = torch.zeros_like(v[..., :1])
        vx, vy, vz = v.unbind(-1)
        return torch.stack([
            torch.stack([ O[...,0], -vz,       vy], -1),
            torch.stack([ vz,       O[...,0], -vx], -1),
            torch.stack([-vy,       vx,       O[...,0]], -1),
        ], -2)

    @classmethod
    def _so3_exp(cls, omega):
        """ Axis-angle → SO(3) """
        theta = torch.norm(omega, dim=-1, keepdim=True).clamp_min(1e-8)
        k = omega / theta
        K = cls._skew(k)
        I = torch.eye(3, device=omega.device, dtype=omega.dtype).expand(K.shape)
        s = torch.sin(theta)[..., None]
        c = torch.cos(theta)[..., None]
        return I + s * K + (1.0 - c) * (K @ K)
    
    @staticmethod
    def _ut_sigma_points_nd(n, alpha, kappa, beta, device, dtype):
        """返回 (2n+1, n) 的 sigma-points（单位协方差下）"""
        lam = alpha**2 * (n + kappa) - n
        scale = math.sqrt(n + lam)
        I = torch.eye(n, device=device, dtype=dtype)
        sigmas = torch.cat([torch.zeros(1, n, device=device, dtype=dtype),
                            +scale * I,
                            -scale * I], dim=0)  # (2n+1, n)
        return sigmas

    @staticmethod
    def _ut_sigma_points_3d(alpha, kappa, beta, device, dtype):
        """ UT for n=3 → 7 sigma points + (Wm, Wc)（这里权重未用到邻域，仅返回 sigmas） """
        n = 3
        lam = alpha**2 * (n + kappa) - n
        I = torch.eye(n, device=device, dtype=dtype)
        scale = math.sqrt(n + lam)
        sigmas = torch.cat([
            torch.zeros(1, n, device=device, dtype=dtype),
            +scale * I,
            -scale * I
        ], dim=0)  # (7,3)
        return sigmas  # (7,3)

    # ===================== Camera/LiDAR IO ===================== #
    @staticmethod
    def _get_transform_matrices(img_metas, device, dtype):
        """
        从 img_metas 提取:
        cam_intrinsics: (B,N,3,3)
        lidar2cam_rt  : (B,N,4,4)
        """
        B = len(img_metas)
        # print(B)

        N = 0
        for b in range(B):
            N = max(N, len(img_metas[b]['lidar2cam']))
        # print(N) 4

        Kin = torch.as_tensor([[1142.51841, 0., 800.],
                       [0., 1142.51841, 450.],
                       [0., 0., 1.]],
                      device=device, dtype=dtype)
        K = torch.zeros(B, N, 3, 3, device=device, dtype=dtype)
        K[:] = Kin  # 广播到 (B,N,3,3)

        T = torch.zeros(B, N, 4, 4, device=device, dtype=dtype)
        #TODO 因为img_meta无法提取内参，但调用pkl文件可以看到无人机使用的摄像头的内参一致因此直接赋值

        for b in range(B):
            # 提取外参矩阵
            if 'lidar2cam' in img_metas[b] and img_metas[b]['lidar2cam']:
                transforms = img_metas[b]['lidar2cam']
                actual_N = min(len(transforms), N)
                
                for n in range(actual_N):
                    # print("成功提取外参")
                    T[b, n] = torch.as_tensor(transforms[n], device=device, dtype=dtype)
                    
            elif 'lidar2cam_rt' in img_metas[b] and img_metas[b]['lidar2cam_rt']:
                transforms = img_metas[b]['lidar2cam_rt']
                actual_N = min(len(transforms), N)
                
                for n in range(actual_N):
                    T[b, n] = torch.as_tensor(transforms[n], device=device, dtype=dtype)
            else:
                raise KeyError(f"batch {b} 缺少 'lidar2cam' 或 'lidar2cam_rt'")
        # print(K.shape,T.shape) (1,4,3,3) (1,4,4,4)
        return K, T

    # ===================== Extrinsic noise (Left-multiply) ===================== #
    def _apply_extrinsic_noise_left(self, R, t):
        # print("run noise")
        #TODO 没问题
        """
        输入:
          R: (B,N,3,3), t: (B,N,3)
        输出:
          R_new = Rn @ R
          t_new = t + dt             (若 trans_in_cam=True, t_new = Rn@t + dt)
          这里不太贴合实际，但为了更加显式的推导公式，进行如此的设计
        """
        cfg = self.extrinsic_noise_cfg
        if not (self.master_enable and cfg.get('enable', False)):
            return R, t

        apply_in = cfg.get('apply_in', 'train')
        # 如果是train模式，仅仅训练时起作用，如果test模式，仅仅在val的时候起作用
        if (apply_in == 'train' and (not self.training)) or (apply_in == 'test' and self.training):
            return R, t
        # 如果概率为0，不起作用
        if torch.rand(1, device=R.device) >= float(cfg.get('prob', 0.0)):
            return R, t

        rot_std = math.radians(float(cfg.get('rot_std_deg', 0.75)))
        trans_std = float(cfg.get('trans_std_m', 0.02))
        omega = torch.randn_like(t) * rot_std          # (B,N,3) 这是对wx，wy，wz的偏移量
        dt    = torch.randn_like(t) * trans_std        # 这是对tx，ty，tz的偏移量
        Rn = self._so3_exp(omega)                      # (B,N,3,3)

        R_new = torch.matmul(Rn, R)
        if bool(cfg.get('trans_in_cam', False)):
            t_new = torch.matmul(Rn, t.unsqueeze(-1)).squeeze(-1) + dt
        else:
            t_new = t + dt
        return R_new, t_new
        # 返回的是扰动后的值。

    # ===================== 反投影（关键修复 #1） ===================== #
    @staticmethod
    def _recover_camera_coords_from_uvz(u_px, v_px, Zc, K):
        """
        [u*Z, v*Z, Z]^T = K [Xc, Yc, Zc]^T  →  [Xc, Yc, Zc]^T = K^{-1}[uZ, vZ, Z]^T
        兼容批维 (N,B) 和额外的 (Q,D) 维：将 (Q,D) 展平做一次 matmul，再还原回去。
        形状约定：
        u_px, v_px, Zc: (..., Q, D)
        K:              (..., 3, 3)   —— 与前缀批维对齐，例如 (...)= (N,B)
        返回：
        Xc, Yc, Zc:     (..., Q, D)
        """
        # 1) 组装 [uZ, vZ, Z]
        uz = u_px * Zc
        vz = v_px * Zc
        # uvz: (..., Q, D, 3)
        uvz = torch.stack([uz, vz, Zc], dim=-1)

        # 2) 计算 K^{-1}，形状 (..., 3, 3)
        K_inv = torch.linalg.inv(K)

        # 3) 将 (Q, D) 展平 → (..., QD, 3)
        *batch_prefix, Q, D, _ = uvz.shape
        uvz_flat = uvz.reshape(*batch_prefix, Q * D, 3)

        # 4) 做一次批量 matmul：(..., 3, 3) @ (..., QD, 3, 1) → (..., QD, 3)
        #    先把 RHS 变成 (..., QD, 3, 1)，再 squeeze 回 (..., QD, 3)
        xyz_flat = torch.matmul(
            K_inv.unsqueeze(-3),           # (..., 1, 3, 3)
            uvz_flat.unsqueeze(-1)         # (..., QD, 3, 1)
        ).squeeze(-1)                      # (..., QD, 3)

        # 5) 还原回 (..., Q, D, 3)
        xyz = xyz_flat.reshape(*batch_prefix, Q, D, 3)

        # 6) 拆分
        Xc = xyz[..., 0]
        Yc = xyz[..., 1]
        # Zc 与输入一致，直接返回
        return Xc, Yc, Zc

    # ===================== 椭圆KNN + Sigma-Points（含关键修复 #2 & 最终数学修正） ===================== #
    def _ellipse_knn_sigma(self, uv_norm_nbqd, Zc_nbqd, K_bn, t_bn, bev_mask_nbqd, img_metas):
        """
        输入:
          uv_norm_nbqd : (N,B,Q,D,2)   归一化像素
          Zc_nbqd      : (N,B,Q,D)  未归一化的像素高度Zc
          K_bn         : (B,N,3,3) 原始K,T
          t_bn         : (B,N,3)
          bev_mask_nbqd: (N,B,Q,D) # 遮掩的部分
        输出:
          ref_neighbors: (N,B,Q,D,K,2)  归一化像素
          neighbor_mask: (N,B,Q,D,K)
        """
        # print("run ellipse_knn_sigma")
        cfg   = self.geo_knn_cfg
        device = uv_norm_nbqd.device
        dtype  = uv_norm_nbqd.dtype
        H = img_metas[0]['img_shape'][0][0]
        W = img_metas[0]['img_shape'][0][1]
        K_sel = int(cfg.get('K', 12)) #TODO K是什么？
        sigma_rad = float(cfg.get('sigma_deg', 1.0)) * math.pi/180.0
        sigma_t   = float(cfg['sigma_trans_m']) if cfg.get('sigma_trans_m') is not None else self.extrinsic_noise_cfg.get('trans_std_m',0.02)
        eps_pix2  = float(cfg.get('eps_pix2', 1.0))

        # (u,v) in pixels
        p_pix = uv_norm_nbqd * uv_norm_nbqd.new_tensor([W, H])  #反归一化 (N,B,Q,D,2)
        u_px, v_px = p_pix[..., 0], p_pix[..., 1] 

        # 反投影求 (Xc,Yc,Zc)，回到相机坐标
        K_nb = K_bn.permute(1,0,2,3)   # (N,B,3,3)
        Xc, Yc, Zc = self._recover_camera_coords_from_uvz(u_px, v_px, Zc_nbqd, K_nb)
        Z = Zc.clamp_min(1e-9)

        # print(f"\n相机坐标检查:")
        # print(f"  Xc: min={Xc.min():.4f}, max={Xc.max():.4f}")
        # print(f"  Yc: min={Yc.min():.4f}, max={Yc.max():.4f}")
        # print(f"  Zc: min={Zc.min():.4f}, max={Zc.max():.4f}")

        # 统一把 fx, fy, s 扩到 (N,B,Q,D)
        fx0 = K_nb[..., 0, 0]             # (N,B)
        fy0 = K_nb[..., 1, 1]             # (N,B)
        s0  = K_nb[..., 0, 1]             # (N,B)
        # 显式扩展，避免依赖广播规则
        fx = fx0.unsqueeze(-1).unsqueeze(-1).expand_as(Z)   # (N,B,Q,D)
        fy = fy0.unsqueeze(-1).unsqueeze(-1).expand_as(Z)   # (N,B,Q,D)
        s  = s0 .unsqueeze(-1).unsqueeze(-1).expand_as(Z)   # (N,B,Q,D)

        # 投影雅可比（像素单位，含 skew s）
        Ju = torch.stack([ fx/Z,      s/Z,  -(fx*Xc + s*Yc)/(Z*Z) ], dim=-1)
        Jv = torch.stack([ torch.zeros_like(Z), fy/Z, -(fy*Yc)/(Z*Z) ], dim=-1)
        J_proj = torch.stack([Ju, Jv], dim=-2)  # (N,B,Q,D,2,3)
        # print(f"\n投影雅可比检查:")
        # print(f"  J_proj shape: {J_proj.shape}")
        # print(f"  J_proj范围: min={J_proj.min():.6f}, max={J_proj.max():.6f}")
        # ===== 最终数学修复：以投影中心 t 为旋转中心 =====
        # ΔP_c ≈ [δω]_x · (P_c - t)  →  ∂P_c/∂ω = -[(P_c - t)]_x
        t_nb = t_bn.permute(1,0,2).unsqueeze(-2).unsqueeze(-2)  # (N,B,1,1,3)
        Pc = torch.stack([Xc, Yc, Zc], dim=-1)                  # (N,B,Q,D,3)
        Pc_centered = Pc - t_nb                                  # (N,B,Q,D,3)
        neg_sk = -self._skew(Pc_centered)                        # (N,B,Q,D,3,3)
        # print(f"\n旋转中心检查:")
        # print(f"  t_nb shape: {t_nb.shape}")
        # print(f"  Pc_centered范围: min={Pc_centered.min():.4f}, max={Pc_centered.max():.4f}")
        # print(f"  neg_sk shape: {neg_sk.shape}")
        # 像素对旋转的雅可比：Jw_pix = ∂(u,v)/∂ω = J_proj @ ∂P_c/∂ω
        Jw_pix = torch.matmul(J_proj, neg_sk)                    # (N,B,Q,D,2,3)
        Jt_pix = J_proj

        # Σ_pix（像素^2）
        I3 = torch.eye(3, device=device, dtype=dtype)
        Sigma_omega = (sigma_rad**2) * I3
        Sigma_t     = (sigma_t**2)   * I3
        Sigma_pix = (torch.matmul(Jw_pix, torch.matmul(Sigma_omega, Jw_pix.transpose(-1, -2)))+torch.matmul(Jt_pix, torch.matmul(Sigma_t,     Jt_pix.transpose(-1, -2))))  # (N,B,Q,D,2,2)
        eye2 = torch.eye(2, device=device, dtype=dtype)
        Sigma_pix = Sigma_pix + eps_pix2 * eye2

        # -------- 基础候选：像素网格 r=3 -------- #
        r_cand = 3
        d_range = torch.arange(-r_cand, r_cand + 1, device=device)
        dvg, dug = torch.meshgrid(d_range, d_range)
        off_pix = torch.stack([dug, dvg], dim=-1).to(dtype).view(1,1,1,1,-1,2)   # (1,1,1,1,M,2)
        M = off_pix.shape[-2]

        base_pix = p_pix.round().unsqueeze(-2)           # (N,B,Q,D,1,2)
        cand_pix = base_pix + off_pix                    # 候选像素(N,B,Q,D,M,2)
        # print(f"\n基础候选点检查:")
        # print(f"  候选点数量: {M}")
        # print(f"  cand_pix shape: {cand_pix.shape}")
        # d_M^2 in 像素域（与 Σ_pix 单位匹配）
        dv_pix = cand_pix - p_pix.unsqueeze(-2)          # 计算候选和原始中心的唯一(N,B,Q,D,M,2)
        invS = torch.linalg.inv(Sigma_pix)               # (N,B,Q,D,2,2)
        dM2 = torch.einsum('...mi,...ij,...mj->...m', dv_pix, invS, dv_pix)  # (N,B,Q,D,M)

        cand_norm = cand_pix / cand_pix.new_tensor([W, H])
        inb = (cand_norm[..., 0] > 0.0) & (cand_norm[..., 0] < 1.0) & \
              (cand_norm[..., 1] > 0.0) & (cand_norm[..., 1] < 1.0) & bev_mask_nbqd.unsqueeze(-1)
        dM2 = torch.where(inb, dM2, torch.full_like(dM2, 1e9))

        K_base = min(K_sel, M)
        topk_idx = dM2.topk(K_base, dim=-1, largest=False).indices     # (N,B,Q,D,Kb)
        gather_idx = topk_idx.unsqueeze(-1).expand(*cand_pix.shape[:-2], K_base, 2) #选取第一批马氏候选点
        neigh_pix = cand_pix.gather(-2, gather_idx)                    # (N,B,Q,D,Kb,2)

        # -------- Sigma-Points（向量化） -------- #
        # ---- 6D Sigma-Points（旋转+平移，向量化） ----
        if bool(cfg.get('use_sigma_points', True)):
            n = 6
            sig6 = self._ut_sigma_points_nd(n,
                                            cfg.get('ut_alpha',1.0),
                                            cfg.get('ut_kappa',0.0),
                                            cfg.get('ut_beta',2.0),
                                            device, dtype)  # (13,6)
            # 各维尺度：[σ_w, σ_w, σ_w, σ_t, σ_t, σ_t]
            scales = torch.tensor([sigma_rad, sigma_rad, sigma_rad,
                                sigma_t,   sigma_t,   sigma_t],
                                device=device, dtype=dtype)  # (6,)
            sig6 = sig6 * scales     # (13,6)

            # J6 = [Jw_pix | Jt_pix] ∈ R^{2x6}
            J6 = torch.cat([Jw_pix, Jt_pix], dim=-1)  # (N,B,Q,D,2,6)
            delta_p = torch.einsum('...ij,mj->...mi', J6, sig6)  # (N,B,Q,D,13,2)
            centers_pix = p_pix.unsqueeze(-2) + delta_p          # (N,B,Q,D,13,2)

            # 每个中心再做一个小 5x5 局部候选
            r2 = 2
            dr = torch.arange(-r2, r2+1, device=device)
            dv2, du2 = torch.meshgrid(dr, dr)
            off2 = torch.stack([du2, dv2], dim=-1).to(dtype).view(1,1,1,1,1,-1,2)  # (1,1,1,1,1,M2,2)

            cand2_pix = centers_pix.unsqueeze(-2) + off2         # (N,B,Q,D,13,M2,2)
            NBQD = cand2_pix.shape[:-2]
            cand2_pix_flat = cand2_pix.flatten(start_dim = -3, end_dim = -2)        # (N,B,Q,D,13*M2,2)

            dv2_pix = cand2_pix_flat - p_pix.unsqueeze(-2)
            dM2_2 = torch.einsum('...mi,...ij,...mj->...m', dv2_pix, invS, dv2_pix)

            cand2_norm = cand2_pix_flat / cand2_pix_flat.new_tensor([W, H])
            inb2 = (cand2_norm[..., 0] > 0.0) & (cand2_norm[..., 0] < 1.0) & \
                (cand2_norm[..., 1] > 0.0) & (cand2_norm[..., 1] < 1.0) & bev_mask_nbqd.unsqueeze(-1)
            dM2_2 = torch.where(inb2, dM2_2, torch.full_like(dM2_2, 1e9))

            all_pix = torch.cat([neigh_pix, cand2_pix_flat], dim=-2)                   # (..., Kb+13*M2, 2)
            all_dM2 = torch.cat([torch.gather(dM2, -1, topk_idx), dM2_2], dim=-1)      # (..., Kb+13*M2)

            K_final = min(K_sel, all_pix.size(-2))
            idx_all = all_dM2.topk(K_final, dim=-1, largest=False).indices
            idx_all = idx_all.unsqueeze(-1).expand(*all_pix.shape[:-2], K_final, 2)
            neigh_pix = all_pix.gather(-2, idx_all)                                     # (N,B,Q,D,K,2)

        ref_neighbors = neigh_pix / neigh_pix.new_tensor([W, H])
        neighbor_mask = (ref_neighbors[..., 0] > 0.0) & (ref_neighbors[..., 0] < 1.0) & \
                        (ref_neighbors[..., 1] > 0.0) & (ref_neighbors[..., 1] < 1.0) & \
                        bev_mask_nbqd.unsqueeze(-1)
        return ref_neighbors.to(dtype), neighbor_mask


    # ===================== 窗口KNN（后备） ===================== #
    @staticmethod
    def _build_window_knn(reference_points_cam, bev_mask, img_metas, K=9, radius=2, include_center=True):
        """
        reference_points_cam: (N,B,Q,D,2) 归一化
        bev_mask            : (N,B,Q,D)
        """
        device = reference_points_cam.device
        dtype  = reference_points_cam.dtype
        H = img_metas[0]['img_shape'][0][0]
        W = img_metas[0]['img_shape'][0][1]

        uv = reference_points_cam
        u_px, v_px = uv[..., 0] * W, uv[..., 1] * H
        base_u, base_v = u_px.round(), v_px.round()

        d_range = torch.arange(-radius, radius + 1, device=device)
        dv, du = torch.meshgrid(d_range, d_range, indexing='ij' if TORCH_VERSION >= '1.10' else 'xy')
        dvdu = torch.stack([du, dv], dim=-1).view(-1, 2)  # (M,2)：(Δu,Δv)
        if not include_center:
            dvdu = dvdu[(dvdu.abs().sum(-1) != 0)]
        M = dvdu.size(0)

        cand_u = base_u.unsqueeze(-1) + dvdu[:, 0]
        cand_v = base_v.unsqueeze(-1) + dvdu[:, 1]
        du2 = (cand_u - u_px.unsqueeze(-1)) ** 2
        dv2 = (cand_v - v_px.unsqueeze(-1)) ** 2
        dist2 = du2 + dv2

        K_sel = min(K, M)
        topk_idx = dist2.topk(K_sel, dim=-1, largest=False).indices
        cand_u = cand_u.gather(-1, topk_idx)
        cand_v = cand_v.gather(-1, topk_idx)

        neigh_u, neigh_v = cand_u / W, cand_v / H
        ref_neighbors = torch.stack([neigh_u, neigh_v], dim=-1)  # (N,B,Q,D,K,2)

        inb = (ref_neighbors[..., 0] > 0.0) & (ref_neighbors[..., 0] < 1.0) & \
              (ref_neighbors[..., 1] > 0.0) & (ref_neighbors[..., 1] < 1.0)
        neighbor_mask = bev_mask.unsqueeze(-1) & inb
        return ref_neighbors.to(dtype), neighbor_mask

    # ===================== 参考点生成（保持原样） ===================== #
    @staticmethod
    def get_reference_points(H, W, Z=8, num_points_in_pillar=4, dim='3d', bs=1, device='cuda', dtype=torch.float):
        if dim == '3d':
            zs = torch.linspace(0.5, Z - 0.5, num_points_in_pillar, dtype=dtype, device=device).view(-1, 1, 1).expand(num_points_in_pillar, H, W) / Z
            xs = torch.linspace(0.5, W - 0.5, W, dtype=dtype, device=device).view(1, 1, W).expand(num_points_in_pillar, H, W) / W
            ys = torch.linspace(0.5, H - 0.5, H, dtype=dtype, device=device).view(1, H, 1).expand(num_points_in_pillar, H, W) / H
            ref_3d = torch.stack((xs, ys, zs), -1)
            ref_3d = ref_3d.permute(0, 3, 1, 2).flatten(2).permute(0, 2, 1)
            ref_3d = ref_3d[None].repeat(bs, 1, 1, 1)
            return ref_3d
        elif dim == '2d':
            ref_y, ref_x = torch.meshgrid(
                torch.linspace(0.5, H - 0.5, H, dtype=dtype, device=device),
                torch.linspace(0.5, W - 0.5, W, dtype=dtype, device=device),
            )
            ref_y = ref_y.reshape(-1)[None] / H
            ref_x = ref_x.reshape(-1)[None] / W
            ref_2d = torch.stack((ref_x, ref_y), -1)
            ref_2d = ref_2d.repeat(bs, 1, 1).unsqueeze(2)
            return ref_2d

    # ===================== 主流程 ===================== #
    @force_fp32(apply_to=('reference_points', 'img_metas'))
    def point_sampling(self, reference_points, pc_range, img_metas):
        # 关闭 TF32（与 mmcv 算子保持一致）
        # TODO 这部分代码的实现功能一致吗？特别是bev_mask?——回答，基本一致
        allow_tf32 = torch.backends.cuda.matmul.allow_tf32
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False

        device = reference_points.device
        dtype  = reference_points.dtype

        # 1) 取 K、T_l2c，获取不同相机的原始的内参，外参-旋转矩阵和平移矩阵
        K_bn, T_l2c = self._get_transform_matrices(img_metas, device, dtype)  # (B,N,3,3), (B,N,4,4)
        B, N = T_l2c.shape[:2]

        # 2) 分解 R,t 并加噪（左乘）
        R_bn = T_l2c[..., :3, :3]
        t_bn = T_l2c[..., :3, 3]
        R_bn, t_bn = self._apply_extrinsic_noise_left(R_bn, t_bn)

        # 3) 重组 T'_l2c，并（如需）重建 lidar2img（K_pad @ [R|t]，无需转置）
        T_l2c_noisy = torch.eye(4, device=device, dtype=dtype).view(1,1,4,4).repeat(B,N,1,1)
        T_l2c_noisy[..., :3, :3] = R_bn
        T_l2c_noisy[..., :3,  3] = t_bn

        # 4) 参考点（归一化 → 实际坐标）
        ref = reference_points.clone()  # (B, num_points, Q, 3)
        ref[..., 0:1] = ref[..., 0:1] * (pc_range[3] - pc_range[0]) + pc_range[0]
        ref[..., 1:2] = ref[..., 1:2] * (pc_range[4] - pc_range[1]) + pc_range[1]
        ref[..., 2:3] = ref[..., 2:3] * (pc_range[5] - pc_range[2]) + pc_range[2]
        ref = torch.cat([ref, torch.ones_like(ref[..., :1])], dim=-1)  # (B, D*?, Q, 4)

        ref = ref.permute(1, 0, 2, 3)  # (D, B, Q, 4)
        D, B2, Q = ref.shape[:3]
        assert B2 == B # 判断两个B是否相同
        # 将参考点进行复制到每一个相机
        ref = ref.view(D, B, 1, Q, 4, 1).repeat(1, 1, N, 1, 1, 1)  # (D,B,N,Q,4,1) N-numera

        # 5) 投影：P_cam = T'_l2c @ P_lidar；P_img = K @ P_cam
        # 做投影，是跟带了扰动的做投影
        T_rep = T_l2c_noisy.view(1, B, N, 1, 4, 4).repeat(D, 1, 1, Q, 1, 1)
        P_cam = (T_rep @ ref).squeeze(-1)[..., :3]                       # (D,B,N,Q,3)
        Zc = P_cam[..., 2].clamp_min(1e-5)
        bev_mask = (Zc > 1e-5)[..., None]                                 # (D,B,N,Q,1)

        K_rep = K_bn.view(1, B, N, 1, 3, 3).repeat(D, 1, 1, Q, 1, 1)
        P_img = (K_rep @ P_cam.unsqueeze(-1)).squeeze(-1)                 # (D,B,N,Q,3)
        u_pix = P_img[..., 0] / Zc
        v_pix = P_img[..., 1] / Zc

        H_img = img_metas[0]['img_shape'][0][0]
        W_img = img_metas[0]['img_shape'][0][1]
        # 回到了像素坐标
        u_n = u_pix / W_img
        v_n = v_pix / H_img

        bev_mask = (bev_mask & (u_n[..., None] > 0.0) & (u_n[..., None] < 1.0) &
                               (v_n[..., None] > 0.0) & (v_n[..., None] < 1.0))  # (D,B,N,Q,1)

        # 整理为 (N,B,Q,D,2)/(N,B,Q,D)
        reference_points_cam = torch.stack([u_n, v_n], dim=-1).permute(2,1,3,0,4)  # (N,B,Q,D,2)
        bev_mask_nbqd = bev_mask.permute(2,1,3,0,4).squeeze(-1)                    # (N,B,Q,D)

        # 6) 邻域：椭圆KNN or 窗口KNN or None
        if self.master_enable and self.geo_knn_cfg.get('enable', False):
            uv_norm_nbqd = reference_points_cam                  # 已经是归一化
            Zc_nbqd      = Zc.permute(2,1,3,0)                   # (N,B,Q,D) 相机坐标系下高度w
            ref_neighbors, neighbor_mask = self._ellipse_knn_sigma(
                uv_norm_nbqd, Zc_nbqd, K_bn, t_bn, bev_mask_nbqd, img_metas #输入的是原始外参，K，T
            )
        elif self.master_enable and self.knn_cfg.get('enable', False):
            ref_neighbors, neighbor_mask = self._build_window_knn(
                reference_points_cam, bev_mask_nbqd, img_metas,
                K=self.knn_cfg['K'], radius=self.knn_cfg['radius'],
                include_center=self.knn_cfg['include_center']
            )
        else:
            ref_neighbors, neighbor_mask = None, None

        # NaN 处理
        if digit_version(TORCH_VERSION) >= digit_version('1.8'):
            bev_mask_nbqd = torch.nan_to_num(bev_mask_nbqd)
        else:
            bev_mask_nbqd = bev_mask_nbqd.new_tensor(np.nan_to_num(bev_mask_nbqd.cpu().numpy()))

        # 还原 TF32
        torch.backends.cuda.matmul.allow_tf32 = allow_tf32
        torch.backends.cudnn.allow_tf32 = allow_tf32

        bev_mask = bev_mask_nbqd

        return reference_points_cam, bev_mask, ref_neighbors, neighbor_mask

    @auto_fp16()
    def forward(self,
                bev_query,
                key,
                value,
                *args,
                bev_h=None,
                bev_w=None,
                bev_pos=None,
                spatial_shapes=None,
                level_start_index=None,
                valid_ratios=None,
                prev_bev=None,
                shift=0.,
                **kwargs):
        """Forward function for `TransformerDecoder`.
        Args:
            bev_query (Tensor): Input BEV query with shape
                `(num_query, bs, embed_dims)`.
            key & value (Tensor): Input multi-cameta features with shape
                (num_cam, num_value, bs, embed_dims)
            reference_points (Tensor): The reference
                points of offset. has shape
                (bs, num_query, 4) when as_two_stage,
                otherwise has shape ((bs, num_query, 2).
            valid_ratios (Tensor): The radios of valid
                points on the feature map, has shape
                (bs, num_levels, 2)
        Returns:
            Tensor: Results with shape [1, num_query, bs, embed_dims] when
                return_intermediate is `False`, otherwise it has shape
                [num_layers, num_query, bs, embed_dims].
        """

        output = bev_query
        intermediate = []

        ref_3d = self.get_reference_points(
            bev_h, bev_w, self.pc_range[5]-self.pc_range[2], self.num_points_in_pillar, dim='3d', bs=bev_query.size(1),  device=bev_query.device, dtype=bev_query.dtype)
        ref_2d = self.get_reference_points(
            bev_h, bev_w, dim='2d', bs=bev_query.size(1), device=bev_query.device, dtype=bev_query.dtype)
        #------------------------------------------
        reference_points_cam, bev_mask, ref_neighbors, neighbor_mask = self.point_sampling(
            ref_3d, self.pc_range, kwargs['img_metas'])
        #------------------------------------------
        # bug: this code should be 'shift_ref_2d = ref_2d.clone()', we keep this bug for reproducing our results in paper.
        shift_ref_2d = ref_2d.clone()
        shift_ref_2d += shift[:, None, None, :]

        # (num_query, bs, embed_dims) -> (bs, num_query, embed_dims)
        bev_query = bev_query.permute(1, 0, 2)
        bev_pos = bev_pos.permute(1, 0, 2)
        bs, len_bev, num_bev_level, _ = ref_2d.shape
        if prev_bev is not None:
            prev_bev = prev_bev.permute(1, 0, 2)
            prev_bev = torch.stack(
                [prev_bev, bev_query], 1).reshape(bs*2, len_bev, -1)
            hybird_ref_2d = torch.stack([shift_ref_2d, ref_2d], 1).reshape(
                bs*2, len_bev, num_bev_level, 2)
        else:
            hybird_ref_2d = torch.stack([ref_2d, ref_2d], 1).reshape(
                bs*2, len_bev, num_bev_level, 2)

        for lid, layer in enumerate(self.layers):
            output = layer(
                bev_query,
                key,
                value,
                *args,
                bev_pos=bev_pos,
                ref_2d=hybird_ref_2d,
                ref_3d=ref_3d,
                bev_h=bev_h,
                bev_w=bev_w,
                spatial_shapes=spatial_shapes,
                level_start_index=level_start_index,
                reference_points_cam=reference_points_cam,
                bev_mask=bev_mask,
                #------------------------
                ref_neighbors=ref_neighbors,
                neighbor_mask=neighbor_mask,
                #-------------------------
                prev_bev=prev_bev,
                **kwargs)

            bev_query = output
            if self.return_intermediate:
                intermediate.append(output)

        if self.return_intermediate:
            return torch.stack(intermediate)

        return output


@TRANSFORMER_LAYER.register_module()
class BEVFormerLayer(MyCustomBaseTransformerLayer):
    """Implements decoder layer in DETR transformer.
    Args:
        attn_cfgs (list[`mmcv.ConfigDict`] | list[dict] | dict )):
            Configs for self_attention or cross_attention, the order
            should be consistent with it in `operation_order`. If it is
            a dict, it would be expand to the number of attention in
            `operation_order`.
        feedforward_channels (int): The hidden dimension for FFNs.
        ffn_dropout (float): Probability of an element to be zeroed
            in ffn. Default 0.0.
        operation_order (tuple[str]): The execution order of operation
            in transformer. Such as ('self_attn', 'norm', 'ffn', 'norm').
            Default：None
        act_cfg (dict): The activation config for FFNs. Default: `LN`
        norm_cfg (dict): Config dict for normalization layer.
            Default: `LN`.
        ffn_num_fcs (int): The number of fully-connected layers in FFNs.
            Default：2.
    """

    def __init__(self,
                 attn_cfgs,
                 feedforward_channels,
                 ffn_dropout=0.0,
                 operation_order=None,
                 act_cfg=dict(type='ReLU', inplace=True),
                 norm_cfg=dict(type='LN'),
                 ffn_num_fcs=2,
                 **kwargs):
        super(BEVFormerLayer, self).__init__(
            attn_cfgs=attn_cfgs,
            feedforward_channels=feedforward_channels,
            ffn_dropout=ffn_dropout,
            operation_order=operation_order,
            act_cfg=act_cfg,
            norm_cfg=norm_cfg,
            ffn_num_fcs=ffn_num_fcs,
            **kwargs)
        self.fp16_enabled = False
        assert len(operation_order) == 6
        assert set(operation_order) == set(
            ['self_attn', 'norm', 'cross_attn', 'ffn'])

    def forward(self,
                query,
                key=None,
                value=None,
                bev_pos=None,
                query_pos=None,
                key_pos=None,
                attn_masks=None,
                query_key_padding_mask=None,
                key_padding_mask=None,
                ref_2d=None,
                ref_3d=None,
                bev_h=None,
                bev_w=None,
                reference_points_cam=None,
                mask=None,
                spatial_shapes=None,
                level_start_index=None,
                prev_bev=None,
                **kwargs):
        """Forward function for `TransformerDecoderLayer`.

        **kwargs contains some specific arguments of attentions.

        Args:
            query (Tensor): The input query with shape
                [num_queries, bs, embed_dims] if
                self.batch_first is False, else
                [bs, num_queries embed_dims].
            key (Tensor): The key tensor with shape [num_keys, bs,
                embed_dims] if self.batch_first is False, else
                [bs, num_keys, embed_dims] .
            value (Tensor): The value tensor with same shape as `key`.
            query_pos (Tensor): The positional encoding for `query`.
                Default: None.
            key_pos (Tensor): The positional encoding for `key`.
                Default: None.
            attn_masks (List[Tensor] | None): 2D Tensor used in
                calculation of corresponding attention. The length of
                it should equal to the number of `attention` in
                `operation_order`. Default: None.
            query_key_padding_mask (Tensor): ByteTensor for `query`, with
                shape [bs, num_queries]. Only used in `self_attn` layer.
                Defaults to None.
            key_padding_mask (Tensor): ByteTensor for `query`, with
                shape [bs, num_keys]. Default: None.

        Returns:
            Tensor: forwarded results with shape [num_queries, bs, embed_dims].
        """

        norm_index = 0
        attn_index = 0
        ffn_index = 0
        identity = query
        if attn_masks is None:
            attn_masks = [None for _ in range(self.num_attn)]
        elif isinstance(attn_masks, torch.Tensor):
            attn_masks = [
                copy.deepcopy(attn_masks) for _ in range(self.num_attn)
            ]
            warnings.warn(f'Use same attn_mask in all attentions in '
                          f'{self.__class__.__name__} ')
        else:
            assert len(attn_masks) == self.num_attn, f'The length of ' \
                                                     f'attn_masks {len(attn_masks)} must be equal ' \
                                                     f'to the number of attention in ' \
                f'operation_order {self.num_attn}'

        for layer in self.operation_order:
            # temporal self attention
            if layer == 'self_attn':

                query = self.attentions[attn_index](
                    query,
                    prev_bev,
                    prev_bev,
                    identity if self.pre_norm else None,
                    query_pos=bev_pos,
                    key_pos=bev_pos,
                    attn_mask=attn_masks[attn_index],
                    key_padding_mask=query_key_padding_mask,
                    reference_points=ref_2d,
                    spatial_shapes=torch.tensor(
                        [[bev_h, bev_w]], device=query.device),
                    level_start_index=torch.tensor([0], device=query.device),
                    **kwargs)
                attn_index += 1
                identity = query

            elif layer == 'norm':
                query = self.norms[norm_index](query)
                norm_index += 1

            # spaital cross attention
            elif layer == 'cross_attn':
                query = self.attentions[attn_index](
                    query,
                    key,
                    value,
                    identity if self.pre_norm else None,
                    query_pos=query_pos,
                    key_pos=key_pos,
                    reference_points=ref_3d,
                    reference_points_cam=reference_points_cam,
                    mask=mask,
                    attn_mask=attn_masks[attn_index],
                    key_padding_mask=key_padding_mask,
                    spatial_shapes=spatial_shapes,
                    level_start_index=level_start_index,
                    **kwargs)
                attn_index += 1
                identity = query

            elif layer == 'ffn':
                query = self.ffns[ffn_index](
                    query, identity if self.pre_norm else None)
                ffn_index += 1

        return query




from mmcv.cnn.bricks.transformer import build_feedforward_network, build_attention


@TRANSFORMER_LAYER.register_module()
class MM_BEVFormerLayer(MyCustomBaseTransformerLayer):
    """multi-modality fusion layer.
    """

    def __init__(self,
                 attn_cfgs,
                 feedforward_channels,
                 ffn_dropout=0.0,
                 operation_order=None,
                 act_cfg=dict(type='ReLU', inplace=True),
                 norm_cfg=dict(type='LN'),
                 ffn_num_fcs=2,
                 lidar_cross_attn_layer=None,
                 **kwargs):
        super(MM_BEVFormerLayer, self).__init__(
            attn_cfgs=attn_cfgs,
            feedforward_channels=feedforward_channels,
            ffn_dropout=ffn_dropout,
            operation_order=operation_order,
            act_cfg=act_cfg,
            norm_cfg=norm_cfg,
            ffn_num_fcs=ffn_num_fcs,
            **kwargs)
        self.fp16_enabled = False
        assert len(operation_order) == 6
        assert set(operation_order) == set(
            ['self_attn', 'norm', 'cross_attn', 'ffn'])
        self.cross_model_weights = torch.nn.Parameter(torch.tensor(0.5), requires_grad=True) 
        if lidar_cross_attn_layer:
            self.lidar_cross_attn_layer = build_attention(lidar_cross_attn_layer)
            # self.cross_model_weights+=1
        else:
            self.lidar_cross_attn_layer = None


    def forward(self,
                query,
                key=None,
                value=None,
                bev_pos=None,
                query_pos=None,
                key_pos=None,
                attn_masks=None,
                query_key_padding_mask=None,
                key_padding_mask=None,
                ref_2d=None,
                ref_3d=None,
                bev_h=None,
                bev_w=None,
                reference_points_cam=None,
                mask=None,
                spatial_shapes=None,
                level_start_index=None,
                prev_bev=None,
                debug=False,
                depth=None,
                depth_z=None,
                lidar_bev=None,
                radar_bev=None,
                **kwargs):
        """Forward function for `TransformerDecoderLayer`.

        **kwargs contains some specific arguments of attentions.

        Args:
            query (Tensor): The input query with shape
                [num_queries, bs, embed_dims] if
                self.batch_first is False, else
                [bs, num_queries embed_dims].
            key (Tensor): The key tensor with shape [num_keys, bs,
                embed_dims] if self.batch_first is False, else
                [bs, num_keys, embed_dims] .
            value (Tensor): The value tensor with same shape as `key`.
            query_pos (Tensor): The positional encoding for `query`.
                Default: None.
            key_pos (Tensor): The positional encoding for `key`.
                Default: None.
            attn_masks (List[Tensor] | None): 2D Tensor used in
                calculation of corresponding attention. The length of
                it should equal to the number of `attention` in
                `operation_order`. Default: None.
            query_key_padding_mask (Tensor): ByteTensor for `query`, with
                shape [bs, num_queries]. Only used in `self_attn` layer.
                Defaults to None.
            key_padding_mask (Tensor): ByteTensor for `query`, with
                shape [bs, num_keys]. Default: None.

        Returns:
            Tensor: forwarded results with shape [num_queries, bs, embed_dims].
        """

        norm_index = 0
        attn_index = 0
        ffn_index = 0
        identity = query
        if attn_masks is None:
            attn_masks = [None for _ in range(self.num_attn)]
        elif isinstance(attn_masks, torch.Tensor):
            attn_masks = [
                copy.deepcopy(attn_masks) for _ in range(self.num_attn)
            ]
            warnings.warn(f'Use same attn_mask in all attentions in '
                          f'{self.__class__.__name__} ')
        else:
            assert len(attn_masks) == self.num_attn, f'The length of ' \
                                                     f'attn_masks {len(attn_masks)} must be equal ' \
                                                     f'to the number of attention in ' \
                f'operation_order {self.num_attn}'

        for layer in self.operation_order:
            # temporal self attention
            if layer == 'self_attn':

                query = self.attentions[attn_index](
                    query,
                    prev_bev,
                    prev_bev,
                    identity if self.pre_norm else None,
                    query_pos=bev_pos,
                    key_pos=bev_pos,
                    attn_mask=attn_masks[attn_index],
                    key_padding_mask=query_key_padding_mask,
                    lidar_bev=lidar_bev,
                    reference_points=ref_2d,
                    spatial_shapes=torch.tensor(
                        [[bev_h, bev_w]], device=query.device),
                    level_start_index=torch.tensor([0], device=query.device),
                    **kwargs)
                attn_index += 1
                identity = query

            elif layer == 'norm':
                query = self.norms[norm_index](query)
                norm_index += 1

            # spaital cross attention
            elif layer == 'cross_attn':
                new_query1 = self.attentions[attn_index](
                    query,
                    key,
                    value,
                    identity if self.pre_norm else None,
                    query_pos=query_pos,
                    key_pos=key_pos,
                    reference_points=ref_3d,
                    reference_points_cam=reference_points_cam,
                    mask=mask,
                    attn_mask=attn_masks[attn_index],
                    key_padding_mask=key_padding_mask,
                    spatial_shapes=spatial_shapes,
                    level_start_index=level_start_index,
                    depth=depth,
                    lidar_bev=lidar_bev,
                    depth_z=depth_z,
                    **kwargs)

                if self.lidar_cross_attn_layer:
                    bs = query.size(0)
                    new_query2 = self.lidar_cross_attn_layer(
                        query,
                        lidar_bev,
                        lidar_bev,
                        reference_points=ref_2d[bs:],
                        spatial_shapes=torch.tensor(
                            [[bev_h, bev_w]], device=query.device),
                        level_start_index=torch.tensor([0], device=query.device),
                        )
                query = new_query1 * self.cross_model_weights + (1-self.cross_model_weights) * new_query2
                attn_index += 1
                identity = query

            elif layer == 'ffn':
                query = self.ffns[ffn_index](
                    query, identity if self.pre_norm else None)
                ffn_index += 1

        return query
