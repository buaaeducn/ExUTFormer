# -*- coding: utf-8 -*-
from mmcv.runner import HOOKS, Hook

@HOOKS.register_module()
class ExtrinsicNoiseSchedulerHook(Hook):
    """
    在每个 epoch 开始时，逐步增大外参噪声:
      - prob:  epoch=1 -> 0.4，之后每轮 +0.1，封顶 0.7
      - rot_std_deg:  epoch=1 -> 0.5°，之后每轮 +0.2°，封顶 2.0°
      - trans_std_m:  epoch=1 -> 0.05m，之后每轮 +0.1m，封顶 0.5m

    说明：
    - 不再改动“椭圆KNN”的旋转/平移不确定性（sigma_*），仅在需要时可选地固定 K。
    - MMCV 的 epoch 从 0 计数；内部使用 e = runner.epoch + 1 映射为“第 e 轮”。
    """

    def __init__(self,
                 total_epochs=24,
                 prob_base=0.4, prob_step=0.1, prob_max=0.7,
                 rot_base=0.5, rot_step=0.2, rot_max=2.0,
                 trans_base=0.05, trans_step=0.1, trans_max=0.5,
                 # 可选：是否固定 geo_knn 的 K；默认不改动任何 geo_knn 配置
                 set_geo_knn=False, knn_K=30):
        self.total_epochs = int(total_epochs)

        self.prob_base = float(prob_base)
        self.prob_step = float(prob_step)
        self.prob_max  = float(prob_max)

        self.rot_base = float(rot_base)
        self.rot_step = float(rot_step)
        self.rot_max  = float(rot_max)

        self.trans_base = float(trans_base)
        self.trans_step = float(trans_step)
        self.trans_max  = float(trans_max)

        self.set_geo_knn = bool(set_geo_knn)
        self.knn_K = int(knn_K)

    # -------- utils --------
    @staticmethod
    def _get_model(runner):
        # 兼容 DDP / 单卡
        return runner.model.module if hasattr(runner.model, 'module') else runner.model

    @staticmethod
    def _safe_get_encoder(model):
        """
        优先常规路径：
            model.pts_bbox_head.transformer.encoder
        若结构不同，则兜底遍历，匹配带 extrinsic_noise_cfg 的模块即可
       （不再强制要求 geo_knn_cfg 存在）。
        """
        try:
            enc = model.pts_bbox_head.transformer.encoder
            if hasattr(enc, 'extrinsic_noise_cfg'):
                return enc
        except Exception:
            pass

        for m in model.modules():
            if hasattr(m, 'extrinsic_noise_cfg'):
                return m

        raise RuntimeError(
            '未能在模型中找到带 extrinsic_noise_cfg 的 Encoder。'
            '请检查路径或类名是否与 BEVFormerEncoder 一致。'
        )

    def _compute_sched(self, e: int):
        """e 为 1-based epoch 序号"""
        prob  = min(self.prob_base  + self.prob_step  * (e - 1), self.prob_max)
        rot   = min(self.rot_base   + self.rot_step   * (e - 1), self.rot_max)
        trans = min(self.trans_base + self.trans_step * (e - 1), self.trans_max)
        return prob, rot, trans

    # -------- MMCV Hook 接口 --------
    def before_run(self, runner):
        """训练启动时：若开启 set_geo_knn，仅固定 K；不再改 sigma_*。"""
        if not self.set_geo_knn:
            return
        model = self._get_model(runner)
        enc = self._safe_get_encoder(model)

        if hasattr(enc, 'geo_knn_cfg') and isinstance(enc.geo_knn_cfg, dict):
            enc.geo_knn_cfg['K'] = self.knn_K
            runner.logger.info(f'[NoiseHook] 固定 geo_knn_cfg.K={self.knn_K}')
        else:
            runner.logger.info('[NoiseHook] 未找到 geo_knn_cfg，跳过固定 K。')

    def before_epoch(self, runner):
        """每轮开始时根据日程更新外参噪声参数。仅在训练时生效。"""
        if runner.mode != 'train':
            return

        model = self._get_model(runner)
        enc = self._safe_get_encoder(model)

        # 把 mmcv 的 0-based epoch 转成 1-based
        e = min(runner.epoch + 1, self.total_epochs)
        prob, rot_deg, trans_m = self._compute_sched(e)

        # 写入 encoder 的动态噪声配置
        cfg = enc.extrinsic_noise_cfg
        cfg['prob'] = float(prob)
        cfg['rot_std_deg'] = float(rot_deg)
        cfg['trans_std_m'] = float(trans_m)
        cfg['enable'] = True  # 确保开启

        runner.logger.info(
            (f'[NoiseHook][Epoch {e}/{self.total_epochs}] '
             f'prob={prob:.3f}, rot_std_deg={rot_deg:.3f}, trans_std_m={trans_m:.3f}')
        )